create definer = root@localhost view vista_alquileres_activos as
select `a`.`id`                                    AS `alquiler_id`,
       `u`.`nombre`                                AS `usuario_nombre`,
       `u`.`email`                                 AS `usuario_email`,
       `c`.`titulo`                                AS `contenido_titulo`,
       `c`.`tipo`                                  AS `contenido_tipo`,
       `a`.`fecha_inicio`                          AS `fecha_inicio`,
       `a`.`fecha_fin`                             AS `fecha_fin`,
       `a`.`precio`                                AS `precio`,
       (to_days(`a`.`fecha_fin`) - to_days(now())) AS `dias_restantes`
from ((`cinearchive_v2`.`alquiler` `a` join `cinearchive_v2`.`usuario` `u`
       on ((`a`.`usuario_id` = `u`.`id`))) join `cinearchive_v2`.`contenido` `c` on ((`a`.`contenido_id` = `c`.`id`)))
where ((`a`.`estado` = 'ACTIVO') and (`a`.`fecha_fin` > now()));

