create definer = root@localhost view vista_ingresos_por_mes as
select date_format(`t`.`fecha_transaccion`, '%Y-%m') AS `mes`,
       count(`t`.`id`)                               AS `total_transacciones`,
       sum(`t`.`monto`)                              AS `ingresos_totales`,
       avg(`t`.`monto`)                              AS `ticket_promedio`
from `cinearchive_v2`.`transaccion` `t`
where (`t`.`estado` = 'COMPLETADA')
group by date_format(`t`.`fecha_transaccion`, '%Y-%m')
order by `mes` desc;

