create definer = root@localhost view vista_contenido_popular as
select `c`.`id`                 AS `id`,
       `c`.`titulo`             AS `titulo`,
       `c`.`tipo`               AS `tipo`,
       `c`.`genero`             AS `genero`,
       count(`a`.`id`)          AS `total_alquileres`,
       avg(`r`.`calificacion`)  AS `calificacion_promedio`,
       count(distinct `r`.`id`) AS `total_resenas`
from ((`cinearchive_v2`.`contenido` `c` left join `cinearchive_v2`.`alquiler` `a`
       on ((`c`.`id` = `a`.`contenido_id`))) left join `cinearchive_v2`.`resena` `r`
      on ((`c`.`id` = `r`.`contenido_id`)))
group by `c`.`id`, `c`.`titulo`, `c`.`tipo`, `c`.`genero`;

